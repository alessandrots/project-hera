package com.outline.org.app.presenter;

public class TesteModel {

//	private Integer id;
	private String title;
	private String text;
	
	
	/**
	 * @return the titletitle
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}
	/**
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}
	
	
}
