package com.outline.org.util;

public class Constante {

	public static final Integer TIPO_RELACIONAMENTO_LOGICO_TI = 0;
	public static final Integer TIPO_RELACIONAMENTO_LOGICO_II = 1;
	public static final Integer TIPO_RELACIONAMENTO_LOGICO_TT = 2;	
	public static final Integer TIPO_RELACIONAMENTO_LOGICO_IT = 3;
	
}
