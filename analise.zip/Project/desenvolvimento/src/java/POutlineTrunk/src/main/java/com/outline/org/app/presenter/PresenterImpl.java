package com.outline.org.app.presenter;

public class PresenterImpl implements IPresenter {

	/**
	 * 
	 */
	private static final long serialVersionUID = 415003370723695586L;

}
