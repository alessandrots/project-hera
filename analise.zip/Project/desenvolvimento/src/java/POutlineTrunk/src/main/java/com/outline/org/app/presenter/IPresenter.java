package com.outline.org.app.presenter;

import java.io.Serializable;

public interface IPresenter extends Serializable {

}
