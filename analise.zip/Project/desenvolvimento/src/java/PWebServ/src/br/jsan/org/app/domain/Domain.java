package br.jsan.org.app.domain;

import java.io.Serializable;

public interface Domain extends Serializable {

	
}
