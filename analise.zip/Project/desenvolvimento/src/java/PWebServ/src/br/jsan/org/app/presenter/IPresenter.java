package br.jsan.org.app.presenter;

import java.io.Serializable;

public interface IPresenter extends Serializable {

}
